﻿UPMP ASP SDK

2013-05-08

==== 文件结构 ====

<ASP sdk>
  │
  ├ class
  │  │
  │  ├ upmp_core.asp ┈┈┈┈┈┈  公用函数文件
  │  │
  │  ├ upmp_md5.asp ┈┈┈┈┈┈┈ MD5签名类文件
  │  │
  │  └ upmp_service.asp  ┈┈┈┈┈接口处理核心类
  │
  ├ conf
  │  │
  │  └ upmp_config.asp ┈┈┈┈┈┈基础配置文件
  │
  ├ examples
  │  │
  │  ├ purchase.asp ┈┈┈┈┈┈┈ 订单推送请求接口实例文件
  │  │
  │  ├ query.asp ┈┈┈┈┈┈┈┈  交易信息查询接口实例文件
  │  │
  │  ├ refund.asp ┈┈┈┈┈┈┈┈ 退货接口实例文件
  │  │
  │  └ void.asp ┈┈┈┈┈┈┈┈┈ 消费撤销接口实例文件
  │
  ├ notify_url.asp ┈┈┈┈┈┈┈┈ 服务器异步通知页面文件
  │
  └ readme.txt  ┈┈┈┈┈┈┈┈┈  使用说明文本


※注意※
请修改配置文件：conf/upmp_config.asp

──────────
 出现问题，求助方法
──────────

如果在集成接口时，有疑问或出现问题，请在qq群提出，我们会有专门的技术支持人员为您处理

