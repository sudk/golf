﻿UPMP ASP.NET SDK

2013-02-05

==== 基本要求 ====

    1. .NET Framework2.0及以上
    2. 支持ASP.NET 2.0的服务器


==== 文件结构 ====

<.NET sdk>
  │
  ├ App_Code
  │  │
  │  ├ UpmpConfig.cs ┈┈┈┈┈┈┈ 基础配置文件
  │  │
  │  ├ UpmpCore.cs ┈┈┈┈┈┈┈┈ 公用函数文件
  │  │
  │  └ UpmpService.cs  ┈┈┈┈┈┈ 接口处理核心类
  │
  ├ examples
  │  │
  │  ├ purchase.aspx ┈┈┈┈┈┈┈ 订单推送请求接口实例文件
  │  ├ purchase.aspx.cs  ┈┈┈┈┈ 订单推送请求接口实例文件
  │  │
  │  ├ query.aspx  ┈┈┈┈┈┈┈┈ 交易信息查询接口实例文件
  │  ├ query.aspx.cs ┈┈┈┈┈┈┈ 交易信息查询接口实例文件
  │  │
  │  ├ refund.aspx ┈┈┈┈┈┈┈┈ 退货接口实例文件
  │  ├ refund.aspx.cs  ┈┈┈┈┈┈ 退货接口实例文件
  │  │
  │  ├ void.aspx ┈┈┈┈┈┈┈┈┈ 消费撤销接口实例文件
  │  └ void.aspx.cs  ┈┈┈┈┈┈┈ 消费撤销接口实例文件
  │
  ├ notify_url.aspx  ┈┈┈┈┈┈┈  服务器异步通知页面文件
  ├ notify_url.aspx.cs ┈┈┈┈┈┈  服务器异步通知页面文件
  │
  └ readme.txt  ┈┈┈┈┈┈┈┈┈┈ 使用说明文本


==== 注意事项 ====

    请修改配置文件：App_Code/UpmpConfig.cs

    命名空间：namespace Com.UnionPay.Upmp

